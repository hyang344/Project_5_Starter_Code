Truffle version: 5.0.21
OpenZeppelin version: 2.3.0
ERC721 Token Name: Peter
ERC721 Token Symbol: 85929
Token address on Rinkebly: 0x431fc6f1f408f1b9d2e69a5810a0516f6b57a41e